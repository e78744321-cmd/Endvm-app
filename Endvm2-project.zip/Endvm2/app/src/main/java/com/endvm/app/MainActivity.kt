package com.endvm.app

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var isoUri: Uri? = null
    private lateinit var isoLabel: TextView
    private lateinit var ramInput: EditText
    private lateinit var cpuInput: EditText
    private lateinit var diskInput: EditText

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 28)
            gravity = Gravity.TOP
        }

        fun heading(text: String) = TextView(this).apply {
            this.text = text
            textSize = 23f
            setPadding(0, 0, 0, 18)
        }
        fun field(hint: String, value: String): EditText =
            EditText(this).apply {
                this.hint = hint
                setSingleLine(true)
                setText(value)
                textSize = 16f
            }
        fun button(text: String, action: () -> Unit) =
            Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }

        root.addView(heading("Endvm 2"))
        root.addView(TextView(this).apply {
            text = "Менеджер виртуальных машин"
            textSize = 16f
        })
        root.addView(isoLabel().also { isoLabel = it })
        root.addView(button("Выбрать ISO") { chooseIso() })
        root.addView(TextView(this).apply { text = "ОЗУ (МБ)" })
        ramInput = field("Например, 2048", "2048")
        root.addView(ramInput)
        root.addView(TextView(this).apply { text = "Ядра CPU" })
        cpuInput = field("Например, 2", "2")
        root.addView(cpuInput)
        root.addView(TextView(this).apply { text = "Размер диска (ГБ)" })
        diskInput = field("Например, 20", "20")
        root.addView(diskInput)
        root.addView(button("Подготовить конфигурацию") { validateConfig() })
        root.addView(TextView(this).apply {
            text = "\nСтатус: оболочка проекта готова. Движок QEMU ARM64 ещё не подключён."
            textSize = 14f
        })
        setContentView(root)
    }

    private fun isoLabel() = TextView(this).apply {
        text = "ISO: не выбран"
        textSize = 15f
        setPadding(0, 24, 0, 4)
    }

    private fun chooseIso() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Deprecated by Android, kept for broad compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            isoUri = data?.data
            isoLabel.text = "ISO: ${isoUri?.lastPathSegment ?: "выбран"}"
            isoUri?.let { contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        }
    }

    private fun validateConfig() {
        val ram = ramInput.text.toString().toIntOrNull()
        val cpu = cpuInput.text.toString().toIntOrNull()
        val disk = diskInput.text.toString().toIntOrNull()
        if (isoUri == null) {
            Toast.makeText(this, "Сначала выбери ISO-файл", Toast.LENGTH_SHORT).show()
            return
        }
        if (ram == null || ram < 512 || cpu == null || cpu !in 1..8 || disk == null || disk < 2) {
            Toast.makeText(this, "Проверь ОЗУ, ядра и размер диска", Toast.LENGTH_LONG).show()
            return
        }
        Toast.makeText(this, "Настройки сохранены. Для запуска нужен подключённый движок QEMU.", Toast.LENGTH_LONG).show()
    }
}
